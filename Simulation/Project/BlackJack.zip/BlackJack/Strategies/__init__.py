from os import sys, path

sys.path.append(path.dirname(__file__))